import javax.swing.*;

public class Main {

    public static void main(String[]args){



        Hoofdscherm h1 = new Hoofdscherm();
        h1.setLocationRelativeTo(null);
        h1.setVisible(true);
        h1.setResizable(false);
        h1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



    }
}
